# Interface de Suivi des Stocks ONU

## Contenu
- `index.html` : Interface principale avec formulaires
- `script.js` : Envoi des données vers Google Sheets
- `style.css` : Mise en forme simple

## Instructions
1. Héberger les fichiers sur GitHub Pages
2. Modifier l'URL dans `script.js` si besoin (`apiURL`)
3. Vérifier que votre Google Web App autorise les requêtes
